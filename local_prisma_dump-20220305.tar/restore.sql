--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.13
-- Dumped by pg_dump version 11.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE prisma;
--
-- Name: prisma; Type: DATABASE; Schema: -; Owner: postgresuser
--

CREATE DATABASE prisma WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE prisma OWNER TO postgresuser;

\connect prisma

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DiscussPostStatus; Type: TYPE; Schema: public; Owner: postgresuser
--

CREATE TYPE public."DiscussPostStatus" AS ENUM (
    'ACTIVE',
    'LOCK',
    'DELETE',
    'ARCHIVE',
    'REPORTED'
);


ALTER TYPE public."DiscussPostStatus" OWNER TO postgresuser;

--
-- Name: DiscussStatus; Type: TYPE; Schema: public; Owner: postgresuser
--

CREATE TYPE public."DiscussStatus" AS ENUM (
    'ACTIVE',
    'LOCK',
    'DELETE',
    'ARCHIVE',
    'REPORTED'
);


ALTER TYPE public."DiscussStatus" OWNER TO postgresuser;

--
-- Name: EmojiCode; Type: TYPE; Schema: public; Owner: postgresuser
--

CREATE TYPE public."EmojiCode" AS ENUM (
    'UP',
    'DOWN',
    'PIN',
    'REPORT'
);


ALTER TYPE public."EmojiCode" OWNER TO postgresuser;

--
-- Name: LikeChoice; Type: TYPE; Schema: public; Owner: postgresuser
--

CREATE TYPE public."LikeChoice" AS ENUM (
    'UP',
    'NEUTRAL'
);


ALTER TYPE public."LikeChoice" OWNER TO postgresuser;

--
-- Name: PollFailReason; Type: TYPE; Schema: public; Owner: postgresuser
--

CREATE TYPE public."PollFailReason" AS ENUM (
    'MIN_VOTES',
    'MIN_JUDGMENTS',
    'MAJOR_VERDICT',
    'VERDICT_AS_FAIL',
    'OTHER'
);


ALTER TYPE public."PollFailReason" OWNER TO postgresuser;

--
-- Name: PollStatus; Type: TYPE; Schema: public; Owner: postgresuser
--

CREATE TYPE public."PollStatus" AS ENUM (
    'OPEN',
    'JUDGE',
    'CLOSE_SUCCESS',
    'CLOSE_FAIL'
);


ALTER TYPE public."PollStatus" OWNER TO postgresuser;

--
-- Name: PollType; Type: TYPE; Schema: public; Owner: postgresuser
--

CREATE TYPE public."PollType" AS ENUM (
    'FIXED',
    'ADD',
    'ADD_BY_POST'
);


ALTER TYPE public."PollType" OWNER TO postgresuser;

--
-- Name: RateChoice; Type: TYPE; Schema: public; Owner: postgresuser
--

CREATE TYPE public."RateChoice" AS ENUM (
    'LONG',
    'SHORT',
    'HOLD'
);


ALTER TYPE public."RateChoice" OWNER TO postgresuser;

--
-- Name: SymType; Type: TYPE; Schema: public; Owner: postgresuser
--

CREATE TYPE public."SymType" AS ENUM (
    'TICKER',
    'TOPIC',
    'URL'
);


ALTER TYPE public."SymType" OWNER TO postgresuser;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Author; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Author" (
    id text NOT NULL,
    name text NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Author" OWNER TO postgresuser;

--
-- Name: Bullet; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Bullet" (
    id text NOT NULL,
    "noteStateId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Bullet" OWNER TO postgresuser;

--
-- Name: BulletEmoji; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."BulletEmoji" (
    id text NOT NULL,
    "bulletId" text NOT NULL,
    code public."EmojiCode" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."BulletEmoji" OWNER TO postgresuser;

--
-- Name: BulletEmojiCount; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."BulletEmojiCount" (
    id integer NOT NULL,
    "bulletEmojiId" text NOT NULL,
    "nViews" integer DEFAULT 0 NOT NULL,
    "nUps" integer DEFAULT 0 NOT NULL,
    "nDowns" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."BulletEmojiCount" OWNER TO postgresuser;

--
-- Name: BulletEmojiCount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."BulletEmojiCount_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BulletEmojiCount_id_seq" OWNER TO postgresuser;

--
-- Name: BulletEmojiCount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."BulletEmojiCount_id_seq" OWNED BY public."BulletEmojiCount".id;


--
-- Name: BulletEmojiLike; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."BulletEmojiLike" (
    id integer NOT NULL,
    "userId" text NOT NULL,
    "bulletEmojiId" text NOT NULL,
    choice public."LikeChoice" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."BulletEmojiLike" OWNER TO postgresuser;

--
-- Name: BulletEmojiLike_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."BulletEmojiLike_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BulletEmojiLike_id_seq" OWNER TO postgresuser;

--
-- Name: BulletEmojiLike_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."BulletEmojiLike_id_seq" OWNED BY public."BulletEmojiLike".id;


--
-- Name: NoteEmojiCount; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."NoteEmojiCount" (
    id integer NOT NULL,
    "nViews" integer DEFAULT 0 NOT NULL,
    "nUps" integer DEFAULT 0 NOT NULL,
    "nDowns" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "noteEmojiId" integer NOT NULL
);


ALTER TABLE public."NoteEmojiCount" OWNER TO postgresuser;

--
-- Name: CardEmojiCount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."CardEmojiCount_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."CardEmojiCount_id_seq" OWNER TO postgresuser;

--
-- Name: CardEmojiCount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."CardEmojiCount_id_seq" OWNED BY public."NoteEmojiCount".id;


--
-- Name: NoteEmojiLike; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."NoteEmojiLike" (
    id integer NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "noteEmojiId" integer NOT NULL,
    liked boolean NOT NULL
);


ALTER TABLE public."NoteEmojiLike" OWNER TO postgresuser;

--
-- Name: CardEmojiLike_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."CardEmojiLike_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."CardEmojiLike_id_seq" OWNER TO postgresuser;

--
-- Name: CardEmojiLike_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."CardEmojiLike_id_seq" OWNED BY public."NoteEmojiLike".id;


--
-- Name: Commit; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Commit" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Commit" OWNER TO postgresuser;

--
-- Name: Discuss; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Discuss" (
    id text NOT NULL,
    "userId" text NOT NULL,
    status public."DiscussStatus" DEFAULT 'ACTIVE'::public."DiscussStatus" NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    title text NOT NULL,
    content text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Discuss" OWNER TO postgresuser;

--
-- Name: DiscussCount; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."DiscussCount" (
    id integer NOT NULL,
    "discussId" text NOT NULL,
    "nPosts" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DiscussCount" OWNER TO postgresuser;

--
-- Name: DiscussCount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."DiscussCount_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DiscussCount_id_seq" OWNER TO postgresuser;

--
-- Name: DiscussCount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."DiscussCount_id_seq" OWNED BY public."DiscussCount".id;


--
-- Name: DiscussEmoji; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."DiscussEmoji" (
    id integer NOT NULL,
    "discussId" text NOT NULL,
    code public."EmojiCode" NOT NULL,
    "nUps" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DiscussEmoji" OWNER TO postgresuser;

--
-- Name: DiscussEmojiCount; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."DiscussEmojiCount" (
    id integer NOT NULL,
    "discussEmojiId" integer NOT NULL,
    "nUps" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DiscussEmojiCount" OWNER TO postgresuser;

--
-- Name: DiscussEmojiCount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."DiscussEmojiCount_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DiscussEmojiCount_id_seq" OWNER TO postgresuser;

--
-- Name: DiscussEmojiCount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."DiscussEmojiCount_id_seq" OWNED BY public."DiscussEmojiCount".id;


--
-- Name: DiscussEmojiLike; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."DiscussEmojiLike" (
    id integer NOT NULL,
    "userId" text NOT NULL,
    "discussEmojiId" integer NOT NULL,
    liked boolean NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DiscussEmojiLike" OWNER TO postgresuser;

--
-- Name: DiscussEmojiLike_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."DiscussEmojiLike_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DiscussEmojiLike_id_seq" OWNER TO postgresuser;

--
-- Name: DiscussEmojiLike_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."DiscussEmojiLike_id_seq" OWNED BY public."DiscussEmojiLike".id;


--
-- Name: DiscussEmoji_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."DiscussEmoji_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DiscussEmoji_id_seq" OWNER TO postgresuser;

--
-- Name: DiscussEmoji_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."DiscussEmoji_id_seq" OWNED BY public."DiscussEmoji".id;


--
-- Name: DiscussPost; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."DiscussPost" (
    id integer NOT NULL,
    "userId" text NOT NULL,
    "discussId" text NOT NULL,
    status public."DiscussPostStatus" DEFAULT 'ACTIVE'::public."DiscussPostStatus" NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DiscussPost" OWNER TO postgresuser;

--
-- Name: DiscussPostEmoji; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."DiscussPostEmoji" (
    id integer NOT NULL,
    "discussPostId" integer NOT NULL,
    code public."EmojiCode" NOT NULL,
    "nUps" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DiscussPostEmoji" OWNER TO postgresuser;

--
-- Name: DiscussPostEmojiCount; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."DiscussPostEmojiCount" (
    id integer NOT NULL,
    "discussPostEmojiId" integer NOT NULL,
    "nUps" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DiscussPostEmojiCount" OWNER TO postgresuser;

--
-- Name: DiscussPostEmojiCount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."DiscussPostEmojiCount_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DiscussPostEmojiCount_id_seq" OWNER TO postgresuser;

--
-- Name: DiscussPostEmojiCount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."DiscussPostEmojiCount_id_seq" OWNED BY public."DiscussPostEmojiCount".id;


--
-- Name: DiscussPostEmojiLike; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."DiscussPostEmojiLike" (
    id integer NOT NULL,
    "userId" text NOT NULL,
    "discussPostEmojiId" integer NOT NULL,
    liked boolean NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DiscussPostEmojiLike" OWNER TO postgresuser;

--
-- Name: DiscussPostEmojiLike_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."DiscussPostEmojiLike_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DiscussPostEmojiLike_id_seq" OWNER TO postgresuser;

--
-- Name: DiscussPostEmojiLike_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."DiscussPostEmojiLike_id_seq" OWNED BY public."DiscussPostEmojiLike".id;


--
-- Name: DiscussPostEmoji_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."DiscussPostEmoji_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DiscussPostEmoji_id_seq" OWNER TO postgresuser;

--
-- Name: DiscussPostEmoji_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."DiscussPostEmoji_id_seq" OWNED BY public."DiscussPostEmoji".id;


--
-- Name: DiscussPost_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."DiscussPost_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DiscussPost_id_seq" OWNER TO postgresuser;

--
-- Name: DiscussPost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."DiscussPost_id_seq" OWNED BY public."DiscussPost".id;


--
-- Name: Link; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Link" (
    id text NOT NULL,
    url text NOT NULL,
    domain text NOT NULL,
    scraped jsonb DEFAULT '{}'::jsonb NOT NULL,
    "authorId" text
);


ALTER TABLE public."Link" OWNER TO postgresuser;

--
-- Name: Note; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Note" (
    id text NOT NULL,
    "symId" text NOT NULL,
    "linkId" text,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Note" OWNER TO postgresuser;

--
-- Name: NoteEmoji; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."NoteEmoji" (
    "noteId" text NOT NULL,
    code public."EmojiCode" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public."NoteEmoji" OWNER TO postgresuser;

--
-- Name: NoteEmoji_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."NoteEmoji_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."NoteEmoji_id_seq" OWNER TO postgresuser;

--
-- Name: NoteEmoji_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."NoteEmoji_id_seq" OWNED BY public."NoteEmoji".id;


--
-- Name: NoteState; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."NoteState" (
    id text NOT NULL,
    "noteId" text NOT NULL,
    "commitId" text NOT NULL,
    "userId" text NOT NULL,
    body jsonb NOT NULL,
    "prevId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NoteState" OWNER TO postgresuser;

--
-- Name: Poll; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Poll" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type public."PollType" DEFAULT 'FIXED'::public."PollType" NOT NULL,
    status public."PollStatus" DEFAULT 'OPEN'::public."PollStatus" NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    choices text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Poll" OWNER TO postgresuser;

--
-- Name: PollCount; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."PollCount" (
    id integer NOT NULL,
    "pollId" text NOT NULL,
    "nVotes" integer[],
    "nJudgments" integer[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PollCount" OWNER TO postgresuser;

--
-- Name: PollCount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."PollCount_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PollCount_id_seq" OWNER TO postgresuser;

--
-- Name: PollCount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."PollCount_id_seq" OWNED BY public."PollCount".id;


--
-- Name: Rate; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Rate" (
    id text NOT NULL,
    "linkId" text,
    "userId" text NOT NULL,
    "authorId" text,
    "symId" text NOT NULL,
    choice public."RateChoice" NOT NULL,
    body jsonb DEFAULT '{}'::jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Rate" OWNER TO postgresuser;

--
-- Name: Sym; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Sym" (
    id text NOT NULL,
    type public."SymType" NOT NULL,
    symbol text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Sym" OWNER TO postgresuser;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL
);


ALTER TABLE public."User" OWNER TO postgresuser;

--
-- Name: Vote; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."Vote" (
    id integer NOT NULL,
    "userId" text NOT NULL,
    "pollId" text NOT NULL,
    "choiceIdx" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Vote" OWNER TO postgresuser;

--
-- Name: Vote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgresuser
--

CREATE SEQUENCE public."Vote_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Vote_id_seq" OWNER TO postgresuser;

--
-- Name: Vote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgresuser
--

ALTER SEQUENCE public."Vote_id_seq" OWNED BY public."Vote".id;


--
-- Name: _DiscussToNote; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public."_DiscussToNote" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_DiscussToNote" OWNER TO postgresuser;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgresuser
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgresuser;

--
-- Name: BulletEmojiCount id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."BulletEmojiCount" ALTER COLUMN id SET DEFAULT nextval('public."BulletEmojiCount_id_seq"'::regclass);


--
-- Name: BulletEmojiLike id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."BulletEmojiLike" ALTER COLUMN id SET DEFAULT nextval('public."BulletEmojiLike_id_seq"'::regclass);


--
-- Name: DiscussCount id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussCount" ALTER COLUMN id SET DEFAULT nextval('public."DiscussCount_id_seq"'::regclass);


--
-- Name: DiscussEmoji id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmoji" ALTER COLUMN id SET DEFAULT nextval('public."DiscussEmoji_id_seq"'::regclass);


--
-- Name: DiscussEmojiCount id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmojiCount" ALTER COLUMN id SET DEFAULT nextval('public."DiscussEmojiCount_id_seq"'::regclass);


--
-- Name: DiscussEmojiLike id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmojiLike" ALTER COLUMN id SET DEFAULT nextval('public."DiscussEmojiLike_id_seq"'::regclass);


--
-- Name: DiscussPost id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPost" ALTER COLUMN id SET DEFAULT nextval('public."DiscussPost_id_seq"'::regclass);


--
-- Name: DiscussPostEmoji id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmoji" ALTER COLUMN id SET DEFAULT nextval('public."DiscussPostEmoji_id_seq"'::regclass);


--
-- Name: DiscussPostEmojiCount id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmojiCount" ALTER COLUMN id SET DEFAULT nextval('public."DiscussPostEmojiCount_id_seq"'::regclass);


--
-- Name: DiscussPostEmojiLike id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmojiLike" ALTER COLUMN id SET DEFAULT nextval('public."DiscussPostEmojiLike_id_seq"'::regclass);


--
-- Name: NoteEmoji id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmoji" ALTER COLUMN id SET DEFAULT nextval('public."NoteEmoji_id_seq"'::regclass);


--
-- Name: NoteEmojiCount id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmojiCount" ALTER COLUMN id SET DEFAULT nextval('public."CardEmojiCount_id_seq"'::regclass);


--
-- Name: NoteEmojiLike id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmojiLike" ALTER COLUMN id SET DEFAULT nextval('public."CardEmojiLike_id_seq"'::regclass);


--
-- Name: PollCount id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."PollCount" ALTER COLUMN id SET DEFAULT nextval('public."PollCount_id_seq"'::regclass);


--
-- Name: Vote id; Type: DEFAULT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Vote" ALTER COLUMN id SET DEFAULT nextval('public."Vote_id_seq"'::regclass);


--
-- Data for Name: Author; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Author" (id, name, meta, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Author" (id, name, meta, "createdAt", "updatedAt") FROM '$$PATH$$/3274.dat';

--
-- Data for Name: Bullet; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Bullet" (id, "noteStateId", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Bullet" (id, "noteStateId", "createdAt", "updatedAt") FROM '$$PATH$$/3275.dat';

--
-- Data for Name: BulletEmoji; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."BulletEmoji" (id, "bulletId", code, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."BulletEmoji" (id, "bulletId", code, "createdAt", "updatedAt") FROM '$$PATH$$/3276.dat';

--
-- Data for Name: BulletEmojiCount; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."BulletEmojiCount" (id, "bulletEmojiId", "nViews", "nUps", "nDowns", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."BulletEmojiCount" (id, "bulletEmojiId", "nViews", "nUps", "nDowns", "createdAt", "updatedAt") FROM '$$PATH$$/3277.dat';

--
-- Data for Name: BulletEmojiLike; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."BulletEmojiLike" (id, "userId", "bulletEmojiId", choice, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."BulletEmojiLike" (id, "userId", "bulletEmojiId", choice, "createdAt", "updatedAt") FROM '$$PATH$$/3279.dat';

--
-- Data for Name: Commit; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Commit" (id, "userId", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Commit" (id, "userId", "createdAt", "updatedAt") FROM '$$PATH$$/3288.dat';

--
-- Data for Name: Discuss; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Discuss" (id, "userId", status, meta, title, content, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Discuss" (id, "userId", status, meta, title, content, "createdAt", "updatedAt") FROM '$$PATH$$/3299.dat';

--
-- Data for Name: DiscussCount; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."DiscussCount" (id, "discussId", "nPosts", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."DiscussCount" (id, "discussId", "nPosts", "createdAt", "updatedAt") FROM '$$PATH$$/3301.dat';

--
-- Data for Name: DiscussEmoji; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."DiscussEmoji" (id, "discussId", code, "nUps", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."DiscussEmoji" (id, "discussId", code, "nUps", "createdAt", "updatedAt") FROM '$$PATH$$/3303.dat';

--
-- Data for Name: DiscussEmojiCount; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."DiscussEmojiCount" (id, "discussEmojiId", "nUps", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."DiscussEmojiCount" (id, "discussEmojiId", "nUps", "createdAt", "updatedAt") FROM '$$PATH$$/3305.dat';

--
-- Data for Name: DiscussEmojiLike; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."DiscussEmojiLike" (id, "userId", "discussEmojiId", liked, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."DiscussEmojiLike" (id, "userId", "discussEmojiId", liked, "createdAt", "updatedAt") FROM '$$PATH$$/3307.dat';

--
-- Data for Name: DiscussPost; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."DiscussPost" (id, "userId", "discussId", status, content, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."DiscussPost" (id, "userId", "discussId", status, content, "createdAt", "updatedAt") FROM '$$PATH$$/3309.dat';

--
-- Data for Name: DiscussPostEmoji; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."DiscussPostEmoji" (id, "discussPostId", code, "nUps", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."DiscussPostEmoji" (id, "discussPostId", code, "nUps", "createdAt", "updatedAt") FROM '$$PATH$$/3311.dat';

--
-- Data for Name: DiscussPostEmojiCount; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."DiscussPostEmojiCount" (id, "discussPostEmojiId", "nUps", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."DiscussPostEmojiCount" (id, "discussPostEmojiId", "nUps", "createdAt", "updatedAt") FROM '$$PATH$$/3313.dat';

--
-- Data for Name: DiscussPostEmojiLike; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."DiscussPostEmojiLike" (id, "userId", "discussPostEmojiId", liked, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."DiscussPostEmojiLike" (id, "userId", "discussPostEmojiId", liked, "createdAt", "updatedAt") FROM '$$PATH$$/3315.dat';

--
-- Data for Name: Link; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Link" (id, url, domain, scraped, "authorId") FROM stdin;
\.
COPY public."Link" (id, url, domain, scraped, "authorId") FROM '$$PATH$$/3289.dat';

--
-- Data for Name: Note; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Note" (id, "symId", "linkId", meta, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Note" (id, "symId", "linkId", meta, "createdAt", "updatedAt") FROM '$$PATH$$/3281.dat';

--
-- Data for Name: NoteEmoji; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."NoteEmoji" ("noteId", code, "createdAt", "updatedAt", id) FROM stdin;
\.
COPY public."NoteEmoji" ("noteId", code, "createdAt", "updatedAt", id) FROM '$$PATH$$/3282.dat';

--
-- Data for Name: NoteEmojiCount; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."NoteEmojiCount" (id, "nViews", "nUps", "nDowns", "createdAt", "updatedAt", "noteEmojiId") FROM stdin;
\.
COPY public."NoteEmojiCount" (id, "nViews", "nUps", "nDowns", "createdAt", "updatedAt", "noteEmojiId") FROM '$$PATH$$/3283.dat';

--
-- Data for Name: NoteEmojiLike; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."NoteEmojiLike" (id, "userId", "createdAt", "updatedAt", "noteEmojiId", liked) FROM stdin;
\.
COPY public."NoteEmojiLike" (id, "userId", "createdAt", "updatedAt", "noteEmojiId", liked) FROM '$$PATH$$/3285.dat';

--
-- Data for Name: NoteState; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."NoteState" (id, "noteId", "commitId", "userId", body, "prevId", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."NoteState" (id, "noteId", "commitId", "userId", body, "prevId", "createdAt", "updatedAt") FROM '$$PATH$$/3287.dat';

--
-- Data for Name: Poll; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Poll" (id, "userId", type, status, meta, choices, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Poll" (id, "userId", type, status, meta, choices, "createdAt", "updatedAt") FROM '$$PATH$$/3290.dat';

--
-- Data for Name: PollCount; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."PollCount" (id, "pollId", "nVotes", "nJudgments", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."PollCount" (id, "pollId", "nVotes", "nJudgments", "createdAt", "updatedAt") FROM '$$PATH$$/3291.dat';

--
-- Data for Name: Rate; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Rate" (id, "linkId", "userId", "authorId", "symId", choice, body, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Rate" (id, "linkId", "userId", "authorId", "symId", choice, body, "createdAt", "updatedAt") FROM '$$PATH$$/3293.dat';

--
-- Data for Name: Sym; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Sym" (id, type, symbol, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Sym" (id, type, symbol, "createdAt", "updatedAt") FROM '$$PATH$$/3294.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."User" (id, email) FROM stdin;
\.
COPY public."User" (id, email) FROM '$$PATH$$/3295.dat';

--
-- Data for Name: Vote; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."Vote" (id, "userId", "pollId", "choiceIdx", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Vote" (id, "userId", "pollId", "choiceIdx", "createdAt", "updatedAt") FROM '$$PATH$$/3296.dat';

--
-- Data for Name: _DiscussToNote; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public."_DiscussToNote" ("A", "B") FROM stdin;
\.
COPY public."_DiscussToNote" ("A", "B") FROM '$$PATH$$/3316.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgresuser
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3298.dat';

--
-- Name: BulletEmojiCount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."BulletEmojiCount_id_seq"', 16, true);


--
-- Name: BulletEmojiLike_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."BulletEmojiLike_id_seq"', 16, true);


--
-- Name: CardEmojiCount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."CardEmojiCount_id_seq"', 24, true);


--
-- Name: CardEmojiLike_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."CardEmojiLike_id_seq"', 24, true);


--
-- Name: DiscussCount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."DiscussCount_id_seq"', 1, false);


--
-- Name: DiscussEmojiCount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."DiscussEmojiCount_id_seq"', 1, false);


--
-- Name: DiscussEmojiLike_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."DiscussEmojiLike_id_seq"', 1, false);


--
-- Name: DiscussEmoji_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."DiscussEmoji_id_seq"', 1, false);


--
-- Name: DiscussPostEmojiCount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."DiscussPostEmojiCount_id_seq"', 1, false);


--
-- Name: DiscussPostEmojiLike_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."DiscussPostEmojiLike_id_seq"', 1, false);


--
-- Name: DiscussPostEmoji_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."DiscussPostEmoji_id_seq"', 1, false);


--
-- Name: DiscussPost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."DiscussPost_id_seq"', 1, false);


--
-- Name: NoteEmoji_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."NoteEmoji_id_seq"', 1, false);


--
-- Name: PollCount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."PollCount_id_seq"', 1, false);


--
-- Name: Vote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgresuser
--

SELECT pg_catalog.setval('public."Vote_id_seq"', 1, false);


--
-- Name: Author Author_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Author"
    ADD CONSTRAINT "Author_pkey" PRIMARY KEY (id);


--
-- Name: BulletEmojiCount BulletEmojiCount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."BulletEmojiCount"
    ADD CONSTRAINT "BulletEmojiCount_pkey" PRIMARY KEY (id);


--
-- Name: BulletEmojiLike BulletEmojiLike_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."BulletEmojiLike"
    ADD CONSTRAINT "BulletEmojiLike_pkey" PRIMARY KEY (id);


--
-- Name: BulletEmoji BulletEmoji_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."BulletEmoji"
    ADD CONSTRAINT "BulletEmoji_pkey" PRIMARY KEY (id);


--
-- Name: Bullet Bullet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Bullet"
    ADD CONSTRAINT "Bullet_pkey" PRIMARY KEY (id);


--
-- Name: Commit Commit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Commit"
    ADD CONSTRAINT "Commit_pkey" PRIMARY KEY (id);


--
-- Name: DiscussCount DiscussCount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussCount"
    ADD CONSTRAINT "DiscussCount_pkey" PRIMARY KEY (id);


--
-- Name: DiscussEmojiCount DiscussEmojiCount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmojiCount"
    ADD CONSTRAINT "DiscussEmojiCount_pkey" PRIMARY KEY (id);


--
-- Name: DiscussEmojiLike DiscussEmojiLike_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmojiLike"
    ADD CONSTRAINT "DiscussEmojiLike_pkey" PRIMARY KEY (id);


--
-- Name: DiscussEmoji DiscussEmoji_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmoji"
    ADD CONSTRAINT "DiscussEmoji_pkey" PRIMARY KEY (id);


--
-- Name: DiscussPostEmojiCount DiscussPostEmojiCount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmojiCount"
    ADD CONSTRAINT "DiscussPostEmojiCount_pkey" PRIMARY KEY (id);


--
-- Name: DiscussPostEmojiLike DiscussPostEmojiLike_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmojiLike"
    ADD CONSTRAINT "DiscussPostEmojiLike_pkey" PRIMARY KEY (id);


--
-- Name: DiscussPostEmoji DiscussPostEmoji_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmoji"
    ADD CONSTRAINT "DiscussPostEmoji_pkey" PRIMARY KEY (id);


--
-- Name: DiscussPost DiscussPost_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPost"
    ADD CONSTRAINT "DiscussPost_pkey" PRIMARY KEY (id);


--
-- Name: Discuss Discuss_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Discuss"
    ADD CONSTRAINT "Discuss_pkey" PRIMARY KEY (id);


--
-- Name: Link Link_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Link"
    ADD CONSTRAINT "Link_pkey" PRIMARY KEY (id);


--
-- Name: NoteEmojiCount NoteEmojiCount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmojiCount"
    ADD CONSTRAINT "NoteEmojiCount_pkey" PRIMARY KEY (id);


--
-- Name: NoteEmojiLike NoteEmojiLike_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmojiLike"
    ADD CONSTRAINT "NoteEmojiLike_pkey" PRIMARY KEY (id);


--
-- Name: NoteEmoji NoteEmoji_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmoji"
    ADD CONSTRAINT "NoteEmoji_pkey" PRIMARY KEY (id);


--
-- Name: NoteState NoteState_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteState"
    ADD CONSTRAINT "NoteState_pkey" PRIMARY KEY (id);


--
-- Name: Note Note_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Note"
    ADD CONSTRAINT "Note_pkey" PRIMARY KEY (id);


--
-- Name: PollCount PollCount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."PollCount"
    ADD CONSTRAINT "PollCount_pkey" PRIMARY KEY (id);


--
-- Name: Poll Poll_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Poll"
    ADD CONSTRAINT "Poll_pkey" PRIMARY KEY (id);


--
-- Name: Rate Rate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Rate"
    ADD CONSTRAINT "Rate_pkey" PRIMARY KEY (id);


--
-- Name: Sym Sym_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Sym"
    ADD CONSTRAINT "Sym_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Vote Vote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Author_name_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "Author_name_key" ON public."Author" USING btree (name);


--
-- Name: BulletEmojiCount_bulletEmojiId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "BulletEmojiCount_bulletEmojiId_key" ON public."BulletEmojiCount" USING btree ("bulletEmojiId");


--
-- Name: BulletEmojiLike_userId_bulletEmojiId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "BulletEmojiLike_userId_bulletEmojiId_key" ON public."BulletEmojiLike" USING btree ("userId", "bulletEmojiId");


--
-- Name: BulletEmoji_bulletId_code_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "BulletEmoji_bulletId_code_key" ON public."BulletEmoji" USING btree ("bulletId", code);


--
-- Name: DiscussCount_discussId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "DiscussCount_discussId_key" ON public."DiscussCount" USING btree ("discussId");


--
-- Name: DiscussEmojiCount_discussEmojiId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "DiscussEmojiCount_discussEmojiId_key" ON public."DiscussEmojiCount" USING btree ("discussEmojiId");


--
-- Name: DiscussEmojiLike_discussEmojiId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "DiscussEmojiLike_discussEmojiId_key" ON public."DiscussEmojiLike" USING btree ("discussEmojiId");


--
-- Name: DiscussEmojiLike_discussEmojiId_userId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "DiscussEmojiLike_discussEmojiId_userId_key" ON public."DiscussEmojiLike" USING btree ("discussEmojiId", "userId");


--
-- Name: DiscussEmoji_code_discussId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "DiscussEmoji_code_discussId_key" ON public."DiscussEmoji" USING btree (code, "discussId");


--
-- Name: DiscussPostEmojiCount_discussPostEmojiId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "DiscussPostEmojiCount_discussPostEmojiId_key" ON public."DiscussPostEmojiCount" USING btree ("discussPostEmojiId");


--
-- Name: DiscussPostEmojiLike_discussPostEmojiId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "DiscussPostEmojiLike_discussPostEmojiId_key" ON public."DiscussPostEmojiLike" USING btree ("discussPostEmojiId");


--
-- Name: DiscussPostEmojiLike_userId_discussPostEmojiId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "DiscussPostEmojiLike_userId_discussPostEmojiId_key" ON public."DiscussPostEmojiLike" USING btree ("userId", "discussPostEmojiId");


--
-- Name: DiscussPostEmoji_code_discussPostId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "DiscussPostEmoji_code_discussPostId_key" ON public."DiscussPostEmoji" USING btree (code, "discussPostId");


--
-- Name: Link_url_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "Link_url_key" ON public."Link" USING btree (url);


--
-- Name: NoteEmojiCount_noteEmojiId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "NoteEmojiCount_noteEmojiId_key" ON public."NoteEmojiCount" USING btree ("noteEmojiId");


--
-- Name: NoteEmojiLike_noteEmojiId_userId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "NoteEmojiLike_noteEmojiId_userId_key" ON public."NoteEmojiLike" USING btree ("noteEmojiId", "userId");


--
-- Name: NoteEmoji_noteId_code_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "NoteEmoji_noteId_code_key" ON public."NoteEmoji" USING btree ("noteId", code);


--
-- Name: NoteState_prevId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "NoteState_prevId_key" ON public."NoteState" USING btree ("prevId");


--
-- Name: Note_linkId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "Note_linkId_key" ON public."Note" USING btree ("linkId");


--
-- Name: Note_symId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "Note_symId_key" ON public."Note" USING btree ("symId");


--
-- Name: PollCount_pollId_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "PollCount_pollId_key" ON public."PollCount" USING btree ("pollId");


--
-- Name: Sym_symbol_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "Sym_symbol_key" ON public."Sym" USING btree (symbol);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: _DiscussToNote_AB_unique; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE UNIQUE INDEX "_DiscussToNote_AB_unique" ON public."_DiscussToNote" USING btree ("A", "B");


--
-- Name: _DiscussToNote_B_index; Type: INDEX; Schema: public; Owner: postgresuser
--

CREATE INDEX "_DiscussToNote_B_index" ON public."_DiscussToNote" USING btree ("B");


--
-- Name: BulletEmojiCount BulletEmojiCount_bulletEmojiId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."BulletEmojiCount"
    ADD CONSTRAINT "BulletEmojiCount_bulletEmojiId_fkey" FOREIGN KEY ("bulletEmojiId") REFERENCES public."BulletEmoji"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: BulletEmojiLike BulletEmojiLike_bulletEmojiId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."BulletEmojiLike"
    ADD CONSTRAINT "BulletEmojiLike_bulletEmojiId_fkey" FOREIGN KEY ("bulletEmojiId") REFERENCES public."BulletEmoji"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: BulletEmojiLike BulletEmojiLike_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."BulletEmojiLike"
    ADD CONSTRAINT "BulletEmojiLike_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: BulletEmoji BulletEmoji_bulletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."BulletEmoji"
    ADD CONSTRAINT "BulletEmoji_bulletId_fkey" FOREIGN KEY ("bulletId") REFERENCES public."Bullet"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Bullet Bullet_noteStateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Bullet"
    ADD CONSTRAINT "Bullet_noteStateId_fkey" FOREIGN KEY ("noteStateId") REFERENCES public."NoteState"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Commit Commit_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Commit"
    ADD CONSTRAINT "Commit_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussCount DiscussCount_discussId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussCount"
    ADD CONSTRAINT "DiscussCount_discussId_fkey" FOREIGN KEY ("discussId") REFERENCES public."Discuss"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussEmojiCount DiscussEmojiCount_discussEmojiId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmojiCount"
    ADD CONSTRAINT "DiscussEmojiCount_discussEmojiId_fkey" FOREIGN KEY ("discussEmojiId") REFERENCES public."DiscussEmoji"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussEmojiLike DiscussEmojiLike_discussEmojiId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmojiLike"
    ADD CONSTRAINT "DiscussEmojiLike_discussEmojiId_fkey" FOREIGN KEY ("discussEmojiId") REFERENCES public."DiscussEmoji"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussEmojiLike DiscussEmojiLike_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmojiLike"
    ADD CONSTRAINT "DiscussEmojiLike_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussEmoji DiscussEmoji_discussId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussEmoji"
    ADD CONSTRAINT "DiscussEmoji_discussId_fkey" FOREIGN KEY ("discussId") REFERENCES public."Discuss"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussPostEmojiCount DiscussPostEmojiCount_discussPostEmojiId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmojiCount"
    ADD CONSTRAINT "DiscussPostEmojiCount_discussPostEmojiId_fkey" FOREIGN KEY ("discussPostEmojiId") REFERENCES public."DiscussPostEmoji"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussPostEmojiLike DiscussPostEmojiLike_discussPostEmojiId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmojiLike"
    ADD CONSTRAINT "DiscussPostEmojiLike_discussPostEmojiId_fkey" FOREIGN KEY ("discussPostEmojiId") REFERENCES public."DiscussPostEmoji"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussPostEmojiLike DiscussPostEmojiLike_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmojiLike"
    ADD CONSTRAINT "DiscussPostEmojiLike_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussPostEmoji DiscussPostEmoji_discussPostId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPostEmoji"
    ADD CONSTRAINT "DiscussPostEmoji_discussPostId_fkey" FOREIGN KEY ("discussPostId") REFERENCES public."DiscussPost"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussPost DiscussPost_discussId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPost"
    ADD CONSTRAINT "DiscussPost_discussId_fkey" FOREIGN KEY ("discussId") REFERENCES public."Discuss"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DiscussPost DiscussPost_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."DiscussPost"
    ADD CONSTRAINT "DiscussPost_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Discuss Discuss_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Discuss"
    ADD CONSTRAINT "Discuss_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Link Link_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Link"
    ADD CONSTRAINT "Link_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."Author"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NoteEmojiCount NoteEmojiCount_noteEmojiId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmojiCount"
    ADD CONSTRAINT "NoteEmojiCount_noteEmojiId_fkey" FOREIGN KEY ("noteEmojiId") REFERENCES public."NoteEmoji"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NoteEmojiLike NoteEmojiLike_noteEmojiId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmojiLike"
    ADD CONSTRAINT "NoteEmojiLike_noteEmojiId_fkey" FOREIGN KEY ("noteEmojiId") REFERENCES public."NoteEmoji"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NoteEmojiLike NoteEmojiLike_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmojiLike"
    ADD CONSTRAINT "NoteEmojiLike_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NoteEmoji NoteEmoji_noteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteEmoji"
    ADD CONSTRAINT "NoteEmoji_noteId_fkey" FOREIGN KEY ("noteId") REFERENCES public."Note"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NoteState NoteState_commitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteState"
    ADD CONSTRAINT "NoteState_commitId_fkey" FOREIGN KEY ("commitId") REFERENCES public."Commit"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NoteState NoteState_noteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteState"
    ADD CONSTRAINT "NoteState_noteId_fkey" FOREIGN KEY ("noteId") REFERENCES public."Note"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NoteState NoteState_prevId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteState"
    ADD CONSTRAINT "NoteState_prevId_fkey" FOREIGN KEY ("prevId") REFERENCES public."NoteState"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NoteState NoteState_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."NoteState"
    ADD CONSTRAINT "NoteState_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Note Note_linkId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Note"
    ADD CONSTRAINT "Note_linkId_fkey" FOREIGN KEY ("linkId") REFERENCES public."Link"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Note Note_symId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Note"
    ADD CONSTRAINT "Note_symId_fkey" FOREIGN KEY ("symId") REFERENCES public."Sym"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PollCount PollCount_pollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."PollCount"
    ADD CONSTRAINT "PollCount_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES public."Poll"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Poll Poll_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Poll"
    ADD CONSTRAINT "Poll_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Rate Rate_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Rate"
    ADD CONSTRAINT "Rate_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."Author"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Rate Rate_linkId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Rate"
    ADD CONSTRAINT "Rate_linkId_fkey" FOREIGN KEY ("linkId") REFERENCES public."Link"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Rate Rate_symId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Rate"
    ADD CONSTRAINT "Rate_symId_fkey" FOREIGN KEY ("symId") REFERENCES public."Sym"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Rate Rate_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Rate"
    ADD CONSTRAINT "Rate_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Vote Vote_pollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES public."Poll"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Vote Vote_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _DiscussToNote _DiscussToNote_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."_DiscussToNote"
    ADD CONSTRAINT "_DiscussToNote_A_fkey" FOREIGN KEY ("A") REFERENCES public."Discuss"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _DiscussToNote _DiscussToNote_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgresuser
--

ALTER TABLE ONLY public."_DiscussToNote"
    ADD CONSTRAINT "_DiscussToNote_B_fkey" FOREIGN KEY ("B") REFERENCES public."Note"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

